# Signals & Systems — Exam Prep

A single-file, offline-first study app for a Signals & Systems course. No build step, no backend, no external requests at runtime — everything (UI, logic, math rendering, question bank) lives in `index.html`. Open it directly in a browser or serve it as a static site.

## What it does

- **Practice Bank** — a question bank with full worked solutions, common-mistake explanations, and quick-solve tricks. Wrong answers always explain *why*.
- **Speed Drills** — short, timer-based rounds for building recall speed.
- **Timed Mock Exams** — full-length practice exams under realistic time pressure.
- **Tricks & Memorize Cards** — condensed rules and patterns for fast recall, with a "tap to reveal" recall mode.
- **Quick-Solve Rules** — a lookup table of trigger → action shortcuts for common problem types.
- **Visual Labs** — interactive diagrams for convolution and transform intuition.
- **Progress Tracking** — per-topic accuracy, a prioritized "retry mistakes / continue unseen / weakest topic" flow, a daily study-day streak, and gentle milestone toasts as you rack up correct answers. It's built to keep motivation up, not to add pressure — there's no countdown clock pushing you to rush.
- **Everything is local** — progress is saved to the browser's `localStorage`. Nothing is sent anywhere. Use the export button (📥) to back up or move your progress as a JSON file.
- **Light & theme-aware** — dark/light toggle, keyboard-friendly search, and a responsive layout that adapts from phones to large monitors without losing any desktop interactions or animations.

## Using it

Just open `index.html` in any modern browser — Chrome, Firefox, Safari, Edge. No installation, no dependencies, no internet connection required after the first load.

## Deploying (GitHub Pages)

A ready-made workflow lives at `.github/workflows/deploy.yml`:

1. Push this repo to GitHub.
2. In the repo settings → **Pages**, set **Source** to **GitHub Actions**.
3. Push to `main` (or run the workflow manually from the **Actions** tab).

The site deploys automatically on every push to `main` — no build step is needed since this is a static single-file app.

## Notes for anyone (human or AI) extending this

- The entire question bank is a JSON blob inside `<script type="application/json" id="bank-data">` — edit it there, not in the rendering code.
- Math is written in LaTeX and rendered client-side by KaTeX (bundled inline, no CDN). Use `$...$` for inline math and `$$...$$` for display math.
- All app logic lives in the final `<script>` block, after the bundled KaTeX library. State is kept in a single `userState` object and persisted via `saveState()`.
- The CSS has no external dependencies; responsive rules live near the end of the main `<style>` block.

---
Made by AR.
